package es.travelworld.traveling

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import es.travelworld.traveling.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    // Usamos ViewBinding para acceder a las vistas del layout activity_home sin usar findViewById
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Inflamos el layout para que esté disponible en código
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Aquí se puede añadir la lógica para los botones o las tarjetas de destinos
    }
}
