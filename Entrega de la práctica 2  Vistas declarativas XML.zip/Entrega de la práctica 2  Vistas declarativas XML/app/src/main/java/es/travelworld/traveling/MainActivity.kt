package es.travelworld.traveling

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import es.travelworld.traveling.databinding.ActivityOnboardingBinding

class MainActivity : AppCompatActivity() {

    // ViewBinding para acceder a las vistas de forma segura
    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Inflamos el layout de Onboarding
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuración del botón de navegación al Home
        binding.btnNext.setOnClickListener {
            // Intent para cambiar de pantalla (Activity)
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            // Finalizamos esta actividad para que el usuario no regrese al onboarding con el botón atrás
            finish()
        }
    }
}
